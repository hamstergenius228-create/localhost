import os
import threading
import urllib.parse
import webbrowser
from http.server import SimpleHTTPRequestHandler
from socketserver import TCPServer
import tkinter as tk
from tkinter import ttk, filedialog, messagebox

class ReusableTCPServer(TCPServer):
    """Allows immediate reuse of the port after stopping the server."""
    allow_reuse_address = True

class LocalhostApp:
    def __init__(self, root):
        self.root = root
        self.root.title("localhost")
        self.root.geometry("520x420")
        self.root.resizable(False, False)

        # Server state
        self.httpd = None
        self.server_thread = None
        self.is_running = False
        self.current_url = ""

        # UI Styling
        self.style = ttk.Style()
        self.style.theme_use("clam")

        self._build_ui()
        self.root.protocol("WM_DELETE_WINDOW", self.on_closing)

    def _build_ui(self):
        main_frame = ttk.Frame(self.root, padding=15)
        main_frame.pack(fill=tk.BOTH, expand=True)

        # Title
        title_label = ttk.Label(main_frame, text="⚡ Localhost HTML Server", font=("Helvetica", 14, "bold"))
        title_label.pack(anchor="w", pady=(0, 15))

        # 1. File Selection Frame
        file_frame = ttk.LabelFrame(main_frame, text=" 1. Select HTML File ", padding=10)
        file_frame.pack(fill=tk.X, pady=(0, 10))

        self.file_path_var = tk.StringVar()
        file_entry = ttk.Entry(file_frame, textvariable=self.file_path_var, width=42)
        file_entry.pack(side=tk.LEFT, padx=(0, 8), fill=tk.X, expand=True)

        browse_btn = ttk.Button(file_frame, text="Browse...", command=self.browse_file)
        browse_btn.pack(side=tk.RIGHT)

        # 2. Server Configuration Frame
        config_frame = ttk.LabelFrame(main_frame, text=" 2. Configure Localhost ", padding=10)
        config_frame.pack(fill=tk.X, pady=(0, 10))

        ttk.Label(config_frame, text="Host:").grid(row=0, column=0, sticky="w", padx=5, pady=5)
        self.host_var = tk.StringVar(value="localhost")
        self.host_entry = ttk.Entry(config_frame, textvariable=self.host_var, width=18)
        self.host_entry.grid(row=0, column=1, sticky="w", padx=5, pady=5)

        ttk.Label(config_frame, text="Port:").grid(row=0, column=2, sticky="w", padx=15, pady=5)
        self.port_var = tk.StringVar(value="8000")
        self.port_entry = ttk.Entry(config_frame, textvariable=self.port_var, width=10)
        self.port_entry.grid(row=0, column=3, sticky="w", padx=5, pady=5)

        # 3. Actions / Start Button
        btn_frame = ttk.Frame(main_frame)
        btn_frame.pack(fill=tk.X, pady=10)

        self.start_btn = ttk.Button(btn_frame, text="Start Server", command=self.toggle_server)
        self.start_btn.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 5))

        self.status_label = ttk.Label(main_frame, text="Status: Stopped 🔴", font=("Helvetica", 10, "italic"))
        self.status_label.pack(anchor="w", pady=(0, 10))

        # 4. Link & Browser Controls Frame
        output_frame = ttk.LabelFrame(main_frame, text=" 3. Generated URL ", padding=10)
        output_frame.pack(fill=tk.X, pady=(0, 5))

        self.url_var = tk.StringVar(value="Server is not running.")
        url_entry = ttk.Entry(output_frame, textvariable=self.url_var, state="readonly")
        url_entry.pack(fill=tk.X, pady=(0, 8))

        actions_subframe = ttk.Frame(output_frame)
        actions_subframe.pack(fill=tk.X)

        self.open_browser_btn = ttk.Button(actions_subframe, text="🌐 Open in Browser", command=self.open_in_browser, state=tk.DISABLED)
        self.open_browser_btn.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 5))

        self.copy_btn = ttk.Button(actions_subframe, text="📋 Copy Link", command=self.copy_link, state=tk.DISABLED)
        self.copy_btn.pack(side=tk.RIGHT, fill=tk.X, expand=True, padx=(5, 0))

    def browse_file(self):
        file_selected = filedialog.askopenfilename(
            title="Select an HTML file",
            filetypes=[("HTML Files", "*.html *.htm"), ("All Files", "*.*")]
        )
        if file_selected:
            self.file_path_var.set(file_selected)

    def toggle_server(self):
        if not self.is_running:
            self.start_server()
        else:
            self.stop_server()

    def start_server(self):
        file_path = self.file_path_var.get().strip()
        host = self.host_var.get().strip()
        port_str = self.port_var.get().strip()

        # Validations
        if not file_path or not os.path.isfile(file_path):
            messagebox.showerror("Error", "Please select a valid .html file first!")
            return

        try:
            port = int(port_str)
            if not (1 <= port <= 65535):
                raise ValueError()
        except ValueError:
            messagebox.showerror("Error", "Port must be an integer between 1 and 65535.")
            return

        directory, filename = os.path.split(file_path)

        # Custom handler serving files from HTML file's parent folder
        handler = lambda *args, **kwargs: SimpleHTTPRequestHandler(*args, directory=directory, **kwargs)

        try:
            self.httpd = ReusableTCPServer((host, port), handler)
        except OSError as e:
            messagebox.showerror("Port Error", f"Could not bind to {host}:{port}.\nError: {e}")
            return

        # Start server loop in a background daemon thread
        self.server_thread = threading.Thread(target=self.httpd.serve_forever, daemon=True)
        self.server_thread.start()

        self.is_running = True
        encoded_filename = urllib.parse.quote(filename)
        self.current_url = f"http://{host}:{port}/{encoded_filename}"

        # Update UI
        self.url_var.set(self.current_url)
        self.status_label.config(text=f"Status: Running at {host}:{port} 🟢")
        self.start_btn.config(text="Stop Server")
        self.open_browser_btn.config(state=tk.NORMAL)
        self.copy_btn.config(state=tk.NORMAL)
        self.host_entry.config(state="disabled")
        self.port_entry.config(state="disabled")

    def stop_server(self):
        if self.httpd:
            self.httpd.shutdown()
            self.httpd.server_close()
            self.httpd = None

        self.is_running = False

        # Reset UI
        self.status_label.config(text="Status: Stopped 🔴")
        self.start_btn.config(text="Start Server")
        self.url_var.set("Server is not running.")
        self.open_browser_btn.config(state=tk.DISABLED)
        self.copy_btn.config(state=tk.DISABLED)
        self.host_entry.config(state="normal")
        self.port_entry.config(state="normal")

    def open_in_browser(self):
        if self.current_url:
            webbrowser.open(self.current_url)

    def copy_link(self):
        if self.current_url:
            self.root.clipboard_clear()
            self.root.clipboard_append(self.current_url)
            messagebox.showinfo("Copied", "Link copied to clipboard!")

    def on_closing(self):
        if self.is_running:
            self.stop_server()
        self.root.destroy()

if __name__ == "__main__":
    root = tk.Tk()
    app = LocalhostApp(root)
    root.mainloop()